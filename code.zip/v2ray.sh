#!/bin/bash

args=$@
is_sh_ver=v4.26

. /etc/v2ray/sh/src/init.sh
